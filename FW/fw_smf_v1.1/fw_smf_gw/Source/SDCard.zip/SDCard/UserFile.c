/*
 * UserFile.c
 *
 *  Created on: Jul 20, 2018
 *      Author: ThaoHuyen
 */
#include <stdio.h>

#include "UserFile.h"


#define macroUSER_FILE_MQTT_CONFIG				"mqttconfig.txt"




/*****************************************************************************
 * Function	: bool bUserFile_Read_MQTTConfig( uint8_t *Host, uint16_t *Port, uint8_t *User, uint8_t *Pwd )
 * Desc		: read mqtt config
 * Param	: None
 * return	: 
 *			+ true - ok
 *			+ false - nok
 *****************************************************************************/
bool bUserFile_Read_MQTTConfig( uint8_t *Host, uint16_t *Port, uint8_t *User, uint8_t *Pwd )
{
	char Buffer[256] = {0};
	char Array[8][48] = {0};
	uint8_t ui = 0, uj = 0, uk = 0;

	if(bFileAccess_Read_All(macroUSER_FILE_MQTT_CONFIG, Buffer) == false)
	{
		APP_DEBUG("--- UserFile: Read mqtt config failture\r\n");
		return false;
	}

	for(ui = 0; Buffer[ui] > 0; ui++)
	{
		if( (Buffer[ui] == '\n') || (Buffer[ui] == '.') )
		{
			uj++;
			uk = 0;
		}
		else if(Buffer[ui] == '\r')
			continue;
		else
		{
			Array[uj][uk++] = Buffer[ui];
		}
	}

	APP_DEBUG("--- UserFile: Host = %s.%s.%s.%s\r\n", Array[0], Array[1], Array[2], Array[3]);
	APP_DEBUG("--- UserFile: Port = %s\r\n", Array[4]);
	APP_DEBUG("--- UserFile: User = %s\r\n", Array[5]);
	APP_DEBUG("--- UserFile: Pwd = %s\r\n", Array[6]);

	Host[0] = atoi(Array[0]);
	Host[1] = atoi(Array[1]);
	Host[2] = atoi(Array[2]);
	Host[3] = atoi(Array[3]);
	*Port = atoi(Array[4]);
	strcpy((char *)User, Array[5]);
	strcpy((char *)Pwd, Array[6]);
	return true;
}




/*****************************************************************************
 * Function	: void vUserFile_Write_MQTTConfig( uint8_t *Host, uint16_t *Port, uint8_t *User, uint8_t *Pwd )
 * Desc		: write mqtt config
 * Param	: None
 * return	: None
 *****************************************************************************/
void vUserFile_Write_MQTTConfig( uint8_t *Host, uint16_t *Port, uint8_t *User, uint8_t *Pwd )
{
	char cStr[256] = {0};

	sprintf(cStr, "%d.%d.%d.%d\r\n%d\r\n%s\r\n%s\r\n", \
					Host[0], Host[1], Host[2], Host[3], \
					*Port, \
					(char *)User, \
					(char *)Pwd \
			);

	if(bFileAccess_Write_All(macroUSER_FILE_MQTT_CONFIG, cStr) == false)
	{
		APP_DEBUG("--- UserFile: Write mqtt config error\r\n");
	}
}





/*****************************************************************************
 * Function	: bool bUserFile_Read_Connectivity_Long_Addr( char *EndDevice_File, uint8_t *LongAddr )
 * Desc		: read long address of connectivity
 * Param	: None
 * return	: true - ok, false - nok
 *****************************************************************************/
bool bUserFile_Read_Connectivity_Long_Addr( char *EndDevice_File, uint8_t *LongAddr )
{
	char Buffer[32] = {0};

	memset((char *)LongAddr, 0, strlen((char *)LongAddr));

	if(bFileAccess_CheckFile_Exist(EndDevice_File) == false)
	{
		APP_DEBUG("--- UserFile: End device not exist\r\n");
		return false;
	}
	if(bFileAccess_Read_All(EndDevice_File, Buffer) == false)
	{
		return false;
	}

	strcpy((char *)LongAddr, Buffer);
	return true;
}




/*****************************************************************************
 * Function	: void vUserFile_Write_Connectivity_Long_Addr( char *EndDevice_File, uint8_t *LongAddr )
 * Desc		: write long address of connectivity
 * Param	: None
 * return	: None
 *****************************************************************************/
void vUserFile_Write_Connectivity_Long_Addr( char *EndDevice_File, uint8_t *LongAddr )
{
	char Buffer[32] = {0};

	memset((char *)LongAddr, 0, strlen((char *)LongAddr));

	if(bFileAccess_Write_All(EndDevice_File, Buffer) == false)
	{
		APP_DEBUG("--- UserFile: Write long address of connectivity fail\r\n");
		return;
	}
}























