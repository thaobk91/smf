
#ifndef __WHOAMITASK_H
#define __WHOAMITASK_H


/******************************************************************************
 * Function		: void vWhoAmITask_Run( void *pvParameters)
 * Description	: Task xu ly ban tin Who Am I
 * Param		: none
 * Return		: none
*******************************************************************************/
void vWhoAmITask_Run( void *pvParameters);


#endif








