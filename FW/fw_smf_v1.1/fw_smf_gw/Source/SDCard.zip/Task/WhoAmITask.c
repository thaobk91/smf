
#include "AppData.h"
#include "WhoAmITask.h"

#ifdef macroCONNECTIVITY_ETH
	#include "EthTask.h"
#endif

#include "IOControl.h"
#include "ProcessMsg.h"
#include "main.h"


//Task
extern taskHandle_t xTask;

//Who am i
extern WhoAmI _WhoAmI;

uint8_t uWhoAmI_SendCounter = 0;
bool Reconnect = false;



/******************************************************************************
 * Function		: void vWhoAmITask_Run( void *pvParameters)
 * Description	: Task xu ly ban tin Who Am I
 * Param		: none
 * Return		: none
*******************************************************************************/
void vWhoAmITask_Run( void *pvParameters)
{
	APP_DEBUG("********************** Who Am I Task *********************\r\n");
	
    while( 1 )
    {
    	xTask.uiWamiTask_Finish = 1;
    	macroTASK_DELAY_MS(10000);

    	if(uWhoAmI_SendCounter >= 3)
    	{
    		if( (_WhoAmI.Network.Wifi == false) && (_WhoAmI.Network._3G == false) && (_WhoAmI.Network._2G == false) )
    		{
    			APP_DEBUG("--- WhoAmITask: network lost. restarting network...\r\n");
    			macroNWK_POWER_OFF();
    			macroNWK_POWER_WIFI_OFF();
    			macroTASK_DELAY_MS(1000);
    			macroNWK_POWER_WIFI_ON();
    			macroNWK_POWER_ON();
    			Reconnect = true;
    		}
    		if( (_WhoAmI.Connectivity.Zigbee == false) && (_WhoAmI.Connectivity.Sub1Ghz == false) )
    		{
    			APP_DEBUG("--- WhoAmITask: connectivity lost. restarting connectivity...\r\n");
    			macroCONN_POWER_OFF();
				macroTASK_DELAY_MS(1000);
				macroCONN_POWER_ON();
				Reconnect = true;
    		}
    		uWhoAmI_SendCounter = 0;
    	}
    	else
    	{
    		uWhoAmI_SendCounter++;
    		_WhoAmI.Network.Wifi = _WhoAmI.Network._2G = _WhoAmI.Network._3G = false;
    		_WhoAmI.Connectivity.Zigbee = _WhoAmI.Connectivity.Sub1Ghz = false;
    		vProcessMsg_Send_Wami();
    	}

		//Task finish
		xTask.uiWamiTask_Finish = 0;
//        vTaskSuspend( NULL );
		if(Reconnect == true)
		{
			Reconnect = false;
			macroTASK_DELAY_MS(10000);
		}
    }
}













