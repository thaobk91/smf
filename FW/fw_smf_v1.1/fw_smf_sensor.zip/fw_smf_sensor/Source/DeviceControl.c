
#include "DeviceControl.h"



/******************************************************************************
 * Function		: void vDeviceControl_Init(void)
 * Description	: Device control init
 * Param		: None
 * Return		: None
*******************************************************************************/
void vDeviceControl_Init(void)
{
	
}






