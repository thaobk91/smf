
#ifndef __SS_LIGHT_H
#define __SS_LIGHT_H

#include "main.h"

#define USE_BH1750_SS


void vSS_Light_Init( void );




void vSS_Light_getLux( uint16_t *uLux );



#endif







