

#ifndef __SS_TEMPANDHUMI_H
#define __SS_TEMPANDHUMI_H

//use sensor type
#define USE_SHT1X



void vSS_TempAndHumi_Air_Index( float *fTemp, float *fHumi );




void vSS_TempAndHumi_Soil_Index( float *fTemp, float *fHumi );



#endif