
#ifndef __SS_PH_H
#define __SS_PH_H

#define USE_PH_ATLAS


#ifdef USE_PH_ATLAS
	#include "SS_PH_Atlas.h"
#endif


void vSS_PH_Init( void );

void vSS_PH_Read( float fTemp );




#endif











